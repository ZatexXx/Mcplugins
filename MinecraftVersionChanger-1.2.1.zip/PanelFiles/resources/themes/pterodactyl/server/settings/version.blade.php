{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    Minecraft Server Version
@endsection

@section('content-header')
    <h1>Minecraft Server Version
        <small>Switch your server version with one click</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li>@lang('navigation.server.configuration')</li>
        <li class="active">Minecraft Server Version</li>
    </ol>
@endsection

@section('content')
    @php ($i = 0)
    @if (count($groups) > 0)
        @foreach($groups as $key => $group)
            @if ($i == 0)
                <div class="row">
                    @endif
                    <div class="col-xs-12 col-md-4">
                        <div class="box box-primary">
                            <div class="box-header with-border text-center">
                                <h3 class="box-title" style="padding-top: 1rem; padding-bottom: 1rem;">{{ $group->name }}</h3>
                            </div>
                            <div class="box-body table-responsive no-padding">
                                <table class="table table-hover table-striped">
                                    <tbody>
                                        @foreach ($group->versions as $version)
                                            <tr>
                                                <td>{{ $version->name }}</td>
                                                <td class="pull-right">
                                                    <form method="post" action="{{ route('server.settings.version.switch', $server->uuidShort) }}" class="version_form">
                                                        {!! csrf_field() !!}

                                                        <input type="hidden" name="group" value="{{ $group->id }}">
                                                        <input type="hidden" name="method" value="{{ $version->method }}">
                                                        <input type="hidden" name="key" value="{{ $version->current_check }}">
                                                        <input type="hidden" name="delete_files" class="delete_files" value="0">

                                                        @if ($current_version['method'] == $version->method && $current_version['key'] == $version->current_check)
                                                            <button type="submit" class="btn btn-warning btn-xs">
                                                                Reinstall
                                                            </button>
                                                        @else
                                                            <button type="submit" class="btn btn-success btn-xs">
                                                                Install
                                                            </button>
                                                        @endif
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    @if ($i == 2 || count($groups) <= $key)
                </div>
            @endif
            @php ($i++)
            @if ($i == 3)
                @php ($i = 0)
            @endif
        @endforeach
    @else
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-info" role="alert">
                    There aren't any selectable version for this server.
                </div>
            </div>
        </div>
    @endif
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
    <script>
        let versionChange = false;

        $('.version_form').on('submit', (event) => {
            if (!versionChange) {
                event.preventDefault();

                swal({
                    title: 'Accept',
                    type: 'warning',
                    text: 'Are you sure that you want change the server version?',
                    showCancelButton: true,
                    confirmButtonText: 'Yes',
                    confirmButtonColor: '#008D4C',
                    closeOnConfirm: false,
                }, () => {
                    swal({
                        title: "Delete Files",
                        text: "Do you want to delete server files?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Yes",
                        cancelButtonText: "No",
                        closeOnConfirm: false,
                        closeOnCancel: false,
                        showLoaderOnConfirm: true,
                    }, function (isConfirm) {
                        if (isConfirm) {
                            $('.delete_files').val('1');
                        } else {
                            $('.delete_files').val('0');
                        }

                        swal({
                            title: 'Processing...',
                            text: 'Version change in progress...',
                            type: 'info'
                        });

                        versionChange = true;

                        setTimeout(() => {
                            event.currentTarget.submit();
                        }, 1000);
                    });
                });
            } else {
                versionChange = false;
            }
        });
    </script>
@endsection
